---
name: remote-server-70-88
description: Remote GPU server management for 10.10.70.88 (oem88) — 8× NVIDIA RTX 5090 32GB (SM 9.0 Blackwell), CUDA 13.0, vLLM + TRTLLM + SGLang serving, proxy access, SSH and operations.
---

# Remote Server 70.88 (oem88)

## Hardware Specs

| Item | Value |
|------|-------|
| Hostname | 10.10.70.88 |
| GPUs | 8× NVIDIA GeForce RTX 5090 32GB (SM 9.0 Blackwell) |
| CUDA | 13.0 |
| Driver | 580.159.03 |
| SSH | `ssh jianliu@10.10.70.88` |

## Environment

**ALWAYS `source ~/.bashrc`** before pip/npm operations — contains proxy and HF_ENDPOINT settings.

```bash
# Standard pattern for all remote commands
ssh jianliu@10.10.70.88 "source ~/.bashrc && <command>"
```

Proxy: `10.10.60.140:7890` (http/https), configured in `~/.bashrc`.

**venv path**: `/data/venvs/vllm-ds4/` — note the **plural** `venvs/`. `/data/venv/` (singular) does not exist.
**SGLang venv**: `/data/venvs/sglang-wan-nvfp4/` — the working SGLang install for wan2.2 uses this separate venv, not `vllm-ds4/`. Verify which venv a script uses before running.

## Installed Packages

Python 3.12.13, torch 2.11.0+cu130, SGLang 0.5.12, safetensors 0.8.0rc1.

## TWO SGLang VEnvs on This Server

This server has **two separate SGLang deployments** — do not conflate them:

| Venv | Path | Used By |
|------|------|---------|
| sglang-wan-nvfp4 | `/data/venvs/sglang-wan-nvfp4/` | `generate` CLI, official test scripts in `~/work/bench_test/wan_2_2_nvfp4/` |
| vllm-ds4 | `/data/venvs/vllm-ds4/` | Manual serving, ad-hoc testing (SGLang 0.5.12 installed here) |

**Always use the correct venv for the task.** The `generate` command and benchmark scripts in `~/work/bench_test/wan_2_2_nvfp4/` use `sglang-wan-nvfp4`, not `vllm-ds4`.

## Network

Proxy-enabled server — PyPI and HuggingFace accessible via `~/.bashrc` proxy settings.
Use **Tsinghua Tuna mirror** (`-i https://pypi.tuna.tsinghua.edu.cn/simple --timeout=30`) for faster, more reliable pip installs on this server.

> See `references/wan22_nvfp4_20260609.md` for Wan2.2 OOM analysis, generate.log error chain, and benchmark test dir reference.

## vLLM

Check status:
```bash
ssh jianliu@10.10.70.88 "source ~/.bashrc && ps aux | grep vllm | grep -v grep"
ssh jianliu@10.10.70.88 "source ~/.bashrc && curl -s http://localhost:8000/v1/models 2>&1 | head -3"
```

Log: `/data/vllm_server.log`

## SGLang Serving

**Two separate SGLang venvs exist on 70.88:**
- `/data/venvs/vllm-ds4/` — vLLM fork venv, SGLang 0.5.12 installed here
- `/data/venvs/sglang-wan-nvfp4/` — dedicated SGLang Wan venv (used by `generate.py`)

User scripts like `generate.py` use the `sglang-wan-nvfp4` venv, NOT `vllm-ds4`.

SGLang 0.5.12 is installed in `/data/venvs/vllm-ds4/`.

**Start SGLang server** (use `sglang-wan-nvfp4` venv):
```bash
MODEL_PATH=/data/models/wan2.2_t2v_A14B_diffusers_nvfp4

ssh jianliu@10.10.70.88 "source ~/.bashrc && \
/data/venvs/sglang-wan-nvfp4/bin/python -m sglang.distributed.launch_server \
  --model-path $MODEL_PATH \
  --port 30000 \
  --host 0.0.0.0 \
  --mem-fraction-static 0.88 \
  --max-running-req 64 2>&1 | tee /data/sglang_server.log"
```

**Health check:**
```bash
curl http://10.10.70.88:30000/v1/models
curl http://10.10.70.88:30000/Health
```

**SGLang streaming chat example:**
```bash
curl http://10.10.70.88:30000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"wan2.2","messages":[{"role":"user","content":"hello"}],"max_tokens":128}' \
  --max-time 60
```

## TRTLLM Serving

### Status: NOT YET INSTALLED

Blocked by dependency conflict. To install:

```bash
# Step 1: Pin fsspec to resolve datasets constraint
ssh jianliu@10.10.70.88 "source ~/.bashrc && \
  /data/venvs/vllm-ds4/bin/pip install 'fsspec==2024.9.0' \
  -i https://pypi.tuna.tsinghua.edu.cn/simple --timeout=30"

# Step 2: Install tensorrt core
ssh jianliu@10.10.70.88 "source ~/.bashrc && \
  /data/venvs/vllm-ds4/bin/pip install tensorrt==11.0.0.114 \
  -i https://pypi.tuna.tsinghua.edu.cn/simple --timeout=30"

# Step 3: Install TRTLLM without deps (deps handled separately)
ssh jianliu@10.10.70.88 "source ~/.bashrc && \
  /data/venvs/vllm-ds4/bin/pip install tensorrt-llm==1.2.1 --no-deps \
  -i https://pypi.tuna.tsinghua.edu.cn/simple --timeout=30"
```

Verify:
```bash
ssh jianliu@10.10.70.88 "source ~/.bashrc && \
  /data/venvs/vllm-ds4/bin/python -c 'import tensorrt; print(tensorrt.__version__)'"
ssh jianliu@10.10.70.88 "source ~/.bashrc && \
  /data/venvs/vllm-ds4/bin/python -c 'import tensorrt_llm; print(tensorrt_llm.__version__)'"
```

**Note**: TRTLLM pre-built wheels target SM 8.x (Ampere/Ada). RTX 5090 is SM 9.0 (Blackwell) — NVIDIA may not yet ship pre-built wheels for SM 9.0 + CUDA 13.0. May require building from source.

## Common Operations

```bash
# GPU status
ssh jianliu@10.10.70.88 nvidia-smi

# GPU topology
ssh jianliu@10.10.70.88 nvidia-smi topo -m

# Disk space
ssh jianliu@10.10.70.88 "df -h /data/"

# Model completeness check (wan2.2: 7 safetensors expected)
ssh jianliu@10.10.70.88 "find /data/models/wan2.2_t2v_A14B_diffusers_nvfp4/ -name '*.safetensors' ! -path '*/.cache/*' | wc -l"

# All pip packages
ssh jianliu@10.10.70.88 "source ~/.bashrc && /data/venvs/vllm-ds4/bin/pip list 2>/dev/null | grep -iE 'sglang|tensorrt|torch|transformers'"

# Wan2.2 benchmark test dirs
ssh jianliu@10.10.70.88 "ls -lt /home/jianliu/work/bench_test/wan_2_2_nvfp4/"
```

## Wan2.2-T2V-A14B on RTX 5090 32GB — CUDA OOM

Wan2.2-T2V-A14B at full precision loads ~29.6 GiB on a 32 GB RTX 5090, leaving virtually no headroom for inference. Symptom: `torch.OutOfMemoryError` during model loading, process dies with `Rank 0 scheduler is dead`.

**Memory-reduction flags for SGLang diffusion serving:**
- `--dit-cpu-offload` — offload diffusion transformer layers to CPU
- `--vae-cpu-offload` — move VAE off GPU during denoising
- `--text-encoder-cpu-offload` — move text encoder off GPU
- `--dit-layerwise-offload` — layer-by-layer CPU offload for transformer
- `--mem-fraction-static 0.88` — limit GPU memory fraction

**Backend test workflow:** Benchmark test dirs in `~/work/bench_test/wan_2_2_nvfp4/` follow naming patterns:
- `wan22_nvfp4_backend_test_<timestamp>` — full backend comparison (cudnn + cutlass)
- `wan22_nvfp4_official_cudnn_cfg_sp<N>_<timestamp>` — cuDNN only, sequence parallel degree N
- `wan22_nvfp4_official_cudnn_sp<N>_<timestamp>` — cuDNN only, simpler config

## References

- `references/wan22-generate-log-analysis.md` — Full analysis of `generate.log` from SGLang Wan2.2 run: CUDA OOM root cause, recovery attempt, mitigations.

## Pitfalls

- **venv path**: Use `/data/venvs/vllm-ds4/` — plural `venvs/`. Singly `/data/venv/` does not exist.
- **Always source .bashrc**: Proxy settings and HF_ENDPOINT are in `~/.bashrc`. Without sourcing, PyPI and HuggingFace network calls fail.
- **Use Tsinghua Tuna mirror**: `-i https://pypi.tuna.tsinghua.edu.cn/simple --timeout=30` — faster and more reliable than default PyPI on this server.
- **SGLang transformers conflict**: SGLang 0.5.12 requires `transformers==5.6.0`. If 5.8.0 is installed, downgrade: `pip install 'transformers==5.6.0'`.
- **TRTLLM SM 9.0**: RTX 5090 SM 9.0 may not have pre-built TRTLLM wheels for CUDA 13.0 — verify after install or prepare for source build.
- **wan2.2 OOM on RTX 5090 32GB**: Full-precision Wan2.2-T2V-A14B exhausts 32GB GPU memory during load (~29.6 GiB in use, ~8 MiB free). Symptoms: server starts then "Rank 0 scheduler is dead" + `EOFError`. Mitigation: try `--dit-cpu-offload`, `--vae-cpu-offload`, `--text-encoder-cpu-offload`, BF16, or SP/Ulysses parallelism. Full diagnostic in `references/wan22_generate_oom_log.md`.
- **fsspec conflict**: TRTLLM's `datasets` dep pins `fsspec<=2024.9.0`. Pin fsspec before installing TRTLLM.
- **Background pip**: For large installs (TRTLLM), run in background with `nohup` to avoid SSH timeout: `ssh ... "source ~/.bashrc && nohup pip install ... > /tmp/install.log 2>&1 &"`
- **RTX 5090 32GB OOM with Wan2.2-T2V-A14B**: The 14B diffusion model (~9.3 GB per transformer shard × 2) exhausts the 32GB GPU. At `performance_mode=speed`, GPU memory hits 29.55/31.36 GiB with only 8.88 MiB free, causing `torch.OutOfMemoryError` during transformer loading. Mitigations: `--vae-cpu-offload`, `--text-encoder-cpu-offload`, `--dit-cpu-offload`, or reduce latent resolution.
- **Two SGLang venvs**: Scripts using SGLang Wan (`generate.py`) use `/data/venvs/sglang-wan-nvfp4/`, not `/data/venvs/vllm-ds4/`. Check which venv a script uses before installing packages.