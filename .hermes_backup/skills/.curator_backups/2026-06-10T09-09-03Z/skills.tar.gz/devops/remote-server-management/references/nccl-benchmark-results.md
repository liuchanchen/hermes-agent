# NCCL Bandwidth Benchmark Results

Summary of nccl-tests all_reduce results across servers.

## 10.10.70.88 (oem88)
- **GPU:** 8× RTX 5090 (32 GB, Blackwell CC 12.0)
- **CUDA:** 13.0 | **NCCL:** 2.28.9
- **Interconnect:** PCIe 5.0 x16 (single NUMA domain)
- **2-card peak BusBW:** ~31 GB/s (near PCIe 5.0 x16 limit ~31.5 GB/s)
- **8-card peak BusBW:** ~31 GB/s (same — single NUMA, no cross-NUMA penalty)
- **Latency floor:** ~14 us @ 8B (2-card), ~30 us (8-card)

## 10.10.70.96 (oem96)
- **GPU:** 8× RTX PRO 6000 Blackwell Server Edition (96 GB, Blackwell CC 12.0)
- **CUDA:** 13.2 | **NCCL:** 2.30.4
- **Interconnect:** PCIe 5.0 x16 + QPI/UPI cross-NUMA
  - GPU0–3 on NUMA0, GPU4–7 on NUMA1
  - `SYS` topology between NUMA domains (PCIe + QPI/UPI)
- **2-card peak BusBW:** 17.49 GB/s (both GPUs on same NUMA, below PCIe 5.0 limit)
- **8-card peak BusBW:** 21.32 GB/s (cross-NUMA QPI/UPI bottleneck caps bandwidth)
- **Latency floor:** 14.85 us @ 8B (2-card), 56.56 us (8-card — cross-NUMA adds ~4×)
- **RDMA:** RoCE v2 via bond0 (ens35f0np0), IP 192.168.66.10/24

## Key Insights

1. **Single-NUMA (70.88) vs dual-NUMA (70.96) matters more than GPU type.** 70.88 achieves ~31 GB/s peak while 70.96 tops at ~21 GB/s, because cross-NUMA traffic must traverse QPI/UPI.
2. **2-card peak on 70.96 (17.49 GB/s) is low** — both GPUs on same NUMA should hit higher. Possible PCIe Gen 4 limitation (GPUs may be running at Gen 1 when idle, need workload to ramp).
3. **8-card AlgoBW on 70.96 (12.18 GB/s vs 2-card 17.49 GB/s)** — Drops because ring topology moves more data per GPU, even though BusBW increases from using more links.
4. **NCCL 2.30.4 vs 2.28.9** — Both work on Blackwell sm120. The difference is CUDA 13.2 vs 13.0, not NCCL version.
