# Benchmark Directories on 70.88

## Standard Layout

Each model has its own dir under `/home/jianliu/work/bench_test/`:

```
deepseekv4_flash/
  start_dsv4_flash_1node.sh    # vLLM single-node TP=8 startup
  test_deepseekv4_throughput_cache.py  # throughput + cache benchmark
  run_benchmark.sh              # wrapper: cache 0/40/80%, 200 req, conc 64
  results/                       # JSON results per run

qwen_3_6/
  start_qwen36.sh               # DP=8, EP, FP8 (working config)
  start_qwen36_1node.sh         # TP8+EP on single-node (FAILS with FP8, see below)

minimax_m2_7/
  start_minimax_m2_nvfp4_tpep.sh  # TP=8 + EP, copied from 70.95

wan_2_2_nvfp4/
  generate                       # SGLang generate CLI
  test_wan22_nvfp4_backends.sh  # backend comparison benchmark

qwen_image_2512/
  test_qwen_image_benchmark.py
  qwen_image_multigpu_server.py
  qwen_image_benchmark_results/
```

## Throughput Benchmark Pattern

All throughput benchmarks use the same script pattern (`test_<model>_throughput_cache.py`). Key conventions:

1. **`--base-url`** must be `http://localhost:8000` — script appends `/v1/chat/completions` internally. Do NOT pass `/v1/completions` or `/v1/chat/completions` as base-url (causes HTTP 404).
2. **`--cache-hit-rate`** is a float: `0.0`, `0.4`, `0.8`.
3. **`--save-json`** saves detailed results to the specified path.
4. **80% cache runs are slow** — set `--request-timeout 900` or run separately outside loops.

## Copying Test Dirs from 70.88

```bash
# To local Downloads
scp -r jianliu@10.10.70.88:/home/jianliu/work/bench_test/<dir> "/mnt/c/Users/liuch/Downloads/"

# Between servers
scp -r jianliu@10.10.70.88:/home/jianliu/work/bench_test/<dir> jianliu@10.10.70.95:/home/jianliu/work/bench_test/
```