---
name: code-review-and-diagnostics
description: Review code changes, diagnose issues, and provide structured feedback for PR reviews and debugging sessions.
version: 1.0.0
author: Hermes Agent
license: MIT
---

# Code Review and Diagnostics

## Purpose
Review code changes, diagnose issues, and provide structured feedback. Used for PR reviews, debugging sessions, and code quality analysis.

## Process
1. Understand the context: what changed, why, and what the expected behavior is.
2. Examine the diff or code systematically: look for logic errors, edge cases, type mismatches, resource leaks, and violations of project conventions.
3. Provide feedback in a clear, structured format: prioritize issues by severity (critical, major, minor), and include concrete suggestions or code snippets for fixes.
4. Avoid lengthy explanations of obvious code patterns or general computer science concepts. Focus on actionable observations.
5. When the user asks for a review or diagnostic, deliver it concisely. Do not preface with disclaimers like "Based on the code, here are my observations" — just state the findings directly.
6. If the user expresses frustration about verbosity or format (e.g., "stop explaining," "just give me the answer"), immediately adjust: shorten responses, remove unnecessary commentary, and present only the essential information.

## Pitfalls
- Do not over-explain basic programming concepts unless the user explicitly asks.
- Avoid meta-commentary like "I notice" or "it appears" — state observations as facts.
- If the user asks for a specific format (e.g., "just the errors"), comply without resistance or justification.
- When the user corrects the style or tone, treat that as a skill update: embed the preference so future sessions default to it.

## Style Preferences (User-Specific)
- Deliver findings directly without introductory fluff.
- Use bullet points or numbered lists for clarity when presenting multiple items.
- Match the user's verbosity: if they are terse, be terse in return.
