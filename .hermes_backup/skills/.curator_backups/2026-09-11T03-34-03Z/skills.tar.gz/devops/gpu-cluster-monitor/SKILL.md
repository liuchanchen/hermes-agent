---
name: gpu-cluster-monitor
version: 1.0.0
description: Operate the GPU monitor dashboard and probe fleet GPUs.
tags: [gpu, monitoring, 70.x, dashboard]
---

# GPU Cluster Monitor (agentless, stdlib)

Tool: /home/jianliu/work/gpu-monitor — real-time per-GPU dashboard for the 12-node
fleet (80 GPUs). Agentless SSH collection; nothing installed on GPU nodes. Full ops
details in its README.md; this skill holds the operating procedures.

## When to Use

- "start/stop/restart the GPU monitor" · "check the fleet" · "is the monitor up"
- Adding/removing a node from the dashboard
- Debugging a node showing offline/stale in the UI
- Any GPU-count or auth drift on 70.99 / 70.106 / 12.12

## How to Run

```bash
# WSL dev instance is now a systemd USER service (2026-09-04) — preferred over nohup:
systemctl --user status|restart|stop gpu-monitor.service
systemctl --user disable gpu-monitor.service        # to stop auto-start at login
journalctl --user -u gpu-monitor.service -n 50      # logs
```

Manual/probe commands (for 70.88 deployment or debugging):

```bash
cd /home/jianliu/work/gpu-monitor
python3 -m backend.main --once                        # one-shot fleet probe -> JSON
python3 -m tests.test_parsers && python3 -m tests.test_idle   # unit tests
pkill -f 'backend.main --port 8787'                    # stop (manual runs only)
nohup python3 -u -m backend.main --port 8787 > /tmp/gpu-monitor.log 2>&1 &   # daemon start
```

- **Run with miniconda python** (`/home/jianliu/miniconda3/bin/python`), NOT
  `/usr/bin/python3` — system python lacks pexpect, so password-auth collectors fail
  at import time (service crash-loop; exit 1 with ModuleNotFoundError in journal).
- WSL service file: `~/.config/systemd/user/gpu-monitor.service` (Restart=always,
  WorkingDirectory=/home/jianliu/work/gpu-monitor). NOTE: WSL systemd user services
  survive only while the WSL VM runs; they die with `wsl --shutdown`.
- **2026-09-04 outage root cause**: the old nohup-launched backend died silently
  (~12:47, no OOM/crash log — likely killed with its parent session), so the web page
  froze on stale data. Fixes shipped: (1) backend now runs under systemd user service
  with auto-restart; (2) frontend polling is ALWAYS on alongside SSE (was: an
  `if (!lastSnap)` gate meant polling never started once SSE had delivered once, so
  a dead backend left the page frozen forever); (3) stale-banner (index.html +
  markStaleBanner in app.js) shows "⚠ 数据已过期 N 分钟" when the newest node
  reading is >3 min old; (4) server.py SSE writes are serialized per-client with a
  lock — the handler keepalive thread and the broadcaster thread previously wrote
  the same socket unsynchronized, corrupting SSE frames.

Verify: `curl -s http://127.0.0.1:8787/api/health` — expect per-node status+GPU counts.

## Shared deployment on 70.88 (2026-09-04)

Production instance runs ON 70.88 for team access: **http://10.10.70.88:8787** (config
`nodes-88.yaml`, code at `~/gpu-monitor/`, log `~/gpu-monitor/run.log`, pid via
`pgrep -af backend.main`). 88 self-monitored via `auth: local` (no SSH hop); from 88,
key-auth reaches 92/94/95/96/98; password (pexpect) reaches 90/93/99/106/66; 12.12
password + 120s interval. Deploy updates: tar the repo (exclude data/__pycache__/docs)
| ssh tar into ~/gpu-monitor, then restart. WSL dev instance may also run on
localhost:8787 — keep only one if SSH load matters.

## Idle highlight (15-min unused feature, ZERO-USAGE memory semantics, 2026-09-04)

GPU flagged `idle: true` when used memory stayed at/below 64 MiB
(IDLE_MEM_FREE_MAX_MB in poller.py) for the ENTIRE past 15 min (window 900 s, needs
≥5 min sample span + ≥3 samples after restart — no false idles on boot).
Zero-usage semantics: nothing allocated in the window = nobody used the GPU.
A GPU that merely HOLDS memory (vLLM worker on 29 GB) is NOT idle — it occupies the
GPU. (History: v1 util≤5% → v2 memory-unchanged ±16MiB → v3 zero-usage, per user.)
UI: blue outline + 💤Nm tag (N = minutes unused). Fields: `gpus[].idle`,
`gpus[].idle_since_min`. Tests: tests/test_idle.py (8 tests).

## Card header field (changed 2026-09-07)

Card top-right shows the node's LATEST SAMPLE TIME (HH:MM:SS from `n.ts`, 24h) —
user request: sample duration (latency_ms) was unhelpful clutter. Drawer subtitle
matches: "… · 最后采样 HH:MM:SS". latency_ms is still in the API payload if needed.
IMPORTANT: 88's deployed app.js had drifted from the repo (repo had the newer
stale-banner/SSE changes; 88 didn't, and vice versa). Always diff 88's file
against the repo BEFORE patching, apply the change to BOTH, and push with a
.bak backup. Frontend is static — no restart needed after app.js push.

## GPU process USER attribution (added 2026-09-07, option A live)

Each processes[] entry has `user` (container/pod name), `image`, `runtime_s`.
Data path: /proc/<pid>/cgroup -> runtime id -> deployed /tmp/.gm_who2.sh
(docker inspect OR sudo crictl inspect; prints id|name|image per id). The script
is auto-deployed on demand via base64 (`_ensure_who`); sudo pw argv only for
auth:local 88 (`sudo -S`); 93/95/98 use passwordless `sudo -n crictl`.
Identity = container/pod name (e.g. PD_nvidia_prefill, dsv4-flash-vision-exp-*).
All compute runs as root inside containers (loginuid unset) — uid is useless.

Pitfalls fixed (do not regress):
- nentry tuple = (name, img, ts): stale check MUST index [2] for ts — [1] is the
  image string → `float - str` TypeError → node offline (96, 2026-09-07)
- _who_lookup returns {full_id: (name, img)} — unpack info[0], info[1]
- pexpect wrapper expands $vars and mangles quotes → build remote cmds via xargs
  and base64-deployed scripts; never inline $vars or nested quotes
- docker ps gives 12-char ids vs 64-char cgroup ids → prefix match
- ps fallback: `ps -o pid=,user=,etimes=` also fills runtime_s (⏱ tag on UI)

## Card header field (changed 2026-09-07)

Symptom: some/all password-auth nodes (90/93/99/106/107) show `stale` with ts
frozen hours/days ago, while key-auth nodes keep updating. run.log shows their
last success then only 66/12.12 fail lines.

Root cause chain: pexpect.spawn (pty.fork) from a poller thread while ANOTHER
thread holds the sqlite mutex → the forked child (still python, pre-exec) runs
threading teardown at fork and deadlocks on the ghost sqlite lock → child never
execs ssh, stays alive holding pty+db fds → parent poller thread blocks forever
in child.expect. Evidence: N single-thread python children of the main proc,
1:1 timestamps with each node's last-success ts, all stuck in
sqlite3VdbeFinalize/futex (gdb via sudo), db fds + /dev/ptmx open, no ssh child.

Fix deployed 2026-09-07 (two layers, both in repo + on 88):
1. Fork-safety guard: `collectors._fork_guard` RLock — pexpect.spawn waits on it;
   poller threads take `collectors.fork_lock_guard()` around store writes +
   latest-registry updates, so pty.fork() can never race a sqlite-lock holder.
2. Watchdog (poller.py `_stuck_child_watchdog`, 60s period): kills our python
   children that are single-threaded + hold ptmx fds + age >120s (never exec'd
   ssh = fork-deadlock signature); logs `[watchdog] killed stuck fork child`.
   Real ssh children (exe=/usr/bin/ssh) are never touched.
Deployed by full restart (old 7-proc tree killed). Verified: all 11 reachable
nodes live, only real-ssh children present, watchdog 0 kills (clean start).
Note: `--once` mode can take >4 min when 12.12/66 hang their full timeouts.

Prevention idea (not yet implemented): use `start_new_session=True` subprocess
sshpass-style or a lock-ordered store write before spawning pexpect; at minimum
add a watchdog that kills single-thread python children holding ptmx.

## Ops pitfalls

- **pkill self-match over SSH**: a remote one-liner containing the pattern
  `backend.main --port 8787` makes pkill kill its own sshd wrapper (exit 255, no
  restart). Restart pattern instead: just `setsid bash -c 'nohup python3 -u -m
  backend.main ... &'` when the old proc is already gone; or use a bracket pattern
  `backend[.]main` when killing from a shell whose own cmdline contains the string.
- **Never prefer the skill's pexpect-ssh.py helper over _pexpect_exec** in
  collectors.py: the helper swaps process-wide sys.stdout (races under concurrent
  collectors → empty fleet output), returns int rc on failure paths
  (`'int' has no attribute 'splitlines'`), and leaks raw SMI output into the server
  log. ssh_exec_blocking must always call the self-contained _pexpect_exec.
- **setsid+nohup over ssh may hang the client** even with </dev/null: run the start
  command in its own ssh call, expect occasional client timeout (exit 124) — verify
  with a SEPARATE ssh call (`ps -ef | grep backend[.]main | wc -l`).
- **Security-gated terminal calls**: repeated curl/urllib to `10.10.70.88` from WSL
  may trip approval gates — batch checks via one ssh call to 88 and read run.log
  locally on 88 instead.

## Architecture (1-paragraph)

One poller thread per node (nodes.yaml: collector/auth/interval_s/timeout_s) →
executes the node's own SMI over SSH (key=subprocess BatchMode, password=self-contained
pexpect in collectors.py) → normalized JSON → SQLite ring (7d) + SSE/REST (stdlib
ThreadingHTTPServer) → vanilla-JS grid UI. No external deps beyond PyYAML+pexpect.

## Collector quirks (verified 2026-09-04)

- nvidia nodes: ALWAYS `/usr/bin/nvidia-smi` (stub wrappers at /usr/local/bin exit 113 on
  88/94-style nodes). 11-field CSV layout, no timestamp field requested.
- wd-smi (70.93): supports nvidia-style `--query-gpu` CSV + `--query-compute-apps`.
  UUID prefix differs between queries (`TGU-…` vs `GPU-…`) — parser joins on guid core.
- warpdgpu-smi (70.99): NO query API — parse the fixed table (GPU-Util `X%(Y%)`,
  Memory-Usage `NMiB / NMiB`, Temp `NC`, Pwr `NW`). No process list available.
- 12.12: SSH takes minutes when loaded → interval_s=120, timeout_s=280, wide stale threshold.

## Fleet drift alerts (check when counts look wrong)

- 70.99 re-imaged twice in one day (TGU01F ×2 → ×8 on 2026-09-04). Verify with
  `warpdgpu-smi | grep -c TGU01F` (via pexpect-ssh.py, password auth).
- 70.106: password auth WORKS, key auth broken. DSpark workload was removed 0904 (idle).
- 70.88 is PRODUCTION RKE2 (MiniMax) — read-only monitoring only, 5s interval.

## Adding a node

1. Probe manually: try `/usr/bin/nvidia-smi --query-gpu=index,... --format=csv,noheader`,
   then `wd-smi ...`, then `warpdgpu-smi` — pick the matching collector.
2. Append to nodes.yaml with correct auth + interval_s/timeout_s.
3. `python3 -m backend.main --once` to verify parsing, then restart the server.