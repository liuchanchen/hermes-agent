---
name: debug-shared-libs
description: Debug dynamic linking / shared object / symbol-loading issues on Linux — missing symbols, SONAME mismatches, DT_NEEDED chains, and LD_LIBRARY_PATH problems.
---

# Debug Shared Libraries

Debug dynamic linking / shared object / symbol-loading issues on Linux: missing symbols, SONAME mismatches, DT_NEEDED chains, and `LD_LIBRARY_PATH` / `ldconfig` ordering.

## Invocation

Call `skill_view(name='debug-shared-libs')` when the user reports a runtime error such as:

- `undefined symbol: <name>` at process startup or dlopen
- `cannot open shared object file: No such file or directory`
- `version 'GLIBC_XX' not found` / `version 'LIBxxxx_YY' not found`
- `lib<name>.so: cannot open shared object file`
- Linter/compiler hints about missing libraries

## When to use

This skill is useful when:

1. A binary or shared library fails to load at runtime with symbol-resolution failures
2. `ldd` or `objdump -p` shows a dependency pointing to the wrong version or missing entirely
3. A `.so` exists on disk but is ignored because its SONAME doesn't match what the loader expects
4. A symbol is expected in one library but actually lives in another, or is available under a different version tag
5. Docker/OCI container images fail at startup with linker errors after a base image change or library upgrade
6. The user has a new build of a library that should supersede the system one but the old one is still picked up

## Steps

### Step 1 – Confirm the symptom

Get the **exact** error message. Common variants:

```
./my_binary: symbol lookup error: /usr/lib/libfoo.so.1: undefined symbol: curl_easy_setopt
```

or

```
./my_binary: error while loading shared libraries: libssl.so.3: cannot open shared object file: No such file or directory
```

If the error appears inside a container, get the container's `docker logs` or the `ENTRYPOINT` / `CMD` output.

### Step 2 – Collect the linkage

For the failing binary or `.so`:

```bash
# What libs does it expect — are any missing?
ldd <binary_or_so> 2>&1

# What SONAME does each dependency carry?
objdump -p <binary_or_so> | grep -E 'NEEDED|SONAME'

# Is the expected SONAME on disk anywhere?
find / -name 'lib<name>.so*' -type f 2>/dev/null
```

For the "missing SONAME" case compare:

```bash
# What was expected?
objdump -p <binary> | grep NEEDED

# What we have
readelf -d /usr/lib/x86_64-linux-gnu/libssl.so.3 2>/dev/null | grep SONAME
```

### Step 2a – User-provided error shortcut

If the user presents a specific error message (e.g., "undefined symbol: curl_easy_setopt" from `ldd` or runtime), **do not** initiate a fresh debugging session or re-ask for repro steps. Assume the error text and the user's description (what runs, which process, what image) are the primary evidence. Jump directly to:

- confirm whether the symbol is expected in a loaded library (`nm -D` / `objdump -T` on the named libs)
- check SONAME vs actual file version (`readelf -d` / `objdump -p`)
- determine whether the missing symbol lives in a lib not on DT_NEEDED or is weak/versioned away

**Pitfall:** Reproducing the error yourself in a new container or rebuilding from source is a distraction unless the user explicitly says "I don't have a reliable repro" or "help me narrow the trigger".

### Step 3 – Search for missing symbol

For `undefined symbol` errors:

```bash
# Is the symbol defined in any library visible to the linker namespace?
nm -D /usr/lib/x86_64-linux-gnu/*.so 2>/dev/null | grep '<symbol_name>'
objdump -T /usr/lib/x86_64-linux-gnu/libcurl.so 2>/dev/null | grep '<symbol_name>'

# Same for the failing library's own dependencies
ldd /usr/lib/libfoo.so.1 | awk '{print $3}' | xargs -I{} sh -c 'echo "{}"; nm -D "{}" 2>/dev/null | grep "<symbol_name>"'
```

Key checks:
- Symbol is **absent** from the loaded library → that lib was built against a newer version / different config
- Symbol is **present but versioned** (e.g., `curl_easy_setopt@@LIBCURL_6`) → the loader got an older SONAME that only exports an unversioned variant
- Symbol is in a library **not on the DT_NEEDED chain** → LD_PRELOAD or dlopen dependency not handled

### Step 4 – Check dlopen / lazy loading

If the error only appears when a plugin / extension / module is loaded at runtime (not at startup):

```bash
# Which lib is triggering the dlopen?
# strace -e openat -f <process> 2>&1 | grep '\.so'    # watch for the last opened .so before the crash
# Or use LD_DEBUG
LD_DEBUG=libs,files <program> 2>&1 | tail -50
```

Common causes:
- Plugin was built against a different SDK version
- Plugin's transitive dependency got upgraded (e.g., system `libcurl.so` but plugin needs `libcurl.so.4`)
- LD_LIBRARY_PATH points to a directory with an older copy of the lib

### Step 5 – Apply the fix

Typical fixes, in rough order:

| Cause | Fix |
|-------|-----|
| Library not installed | `apt install` or copy the correct `.so` into the image |
| Wrong SONAME | Symlink: `ln -s libfoo.so.2 libfoo.so.1` (if ABI compatible) |
| Duplicate/conflicting libs | Check `LD_LIBRARY_PATH` order; remove stale copies |
| Missing versioned symbol | Rebuild client against the installed lib version |
| dlopen dependency not available | Install the missing transitive lib or set `LD_LIBRARY_PATH` |
| Weak symbol / version script | Check `objdump -T` output for `GLIBC_PRIVATE` or hidden visibility |

### Step 6 – Verify

```bash
ldd <binary> | grep 'not found'
# or run the process briefly
<binary> --version  2>&1
```

## Container / Docker-Image specific

When the bug happens inside a container:

```bash
# Inspect the image
docker run --rm <image> ldd /path/to/binary

# Compare to host
docker run --rm -v /host/lib:/host_lib:ro <image> \
  sh -c 'LD_LIBRARY_PATH=/host_lib:$LD_LIBRARY_PATH ldd /binary'
```

Typical container issues:
- Multi-stage build copy misses transitive `.so` files
- `apt upgrade` in the final stage bumped a lib past what the compiled binary expects
- Base image provides libs under different paths (e.g., `/usr/lib64/` vs `/usr/lib/x86_64-linux-gnu/`)

## Pitfalls

- **`ldd` on foreign architecture binaries** shows wrong results (use `readelf -d` instead)
- **Version scripts / symbol visibility**: `nm -D` may show the symbol but it's marked `GLIBC_PRIVATE` or hidden
- **`LD_PRELOAD` interference**: a preloaded lib can intercept symbols and fail in unexpected ways; check with `LD_DEBUG=all`
- **`libpthread.so` / `libdl.so` merge into glibc 2.34+**: these are stub libs; `undefined symbol` for `pthread_create` in glibc ≥ 2.34 means the binary wasn't linked with `-lpthread` (now empty) against the right glibc
- **Bazel / Nix / Conda environments**: their own ld.so wrappers or `RPATH` may bypass system paths entirely — check `patchelf --print-rpath` or `chrpath -l`
