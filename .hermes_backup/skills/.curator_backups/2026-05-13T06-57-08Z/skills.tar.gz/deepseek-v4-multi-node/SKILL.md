---
name: deepseek-v4-multi-node
description: Start and manage DeepSeek-V4-Pro vLLM server across multiple GPU nodes — FP8 block_k constraint, DP+EP config, troubleshooting memory and dimension issues.
---

# DeepSeek-V4 Multi-Node Setup

Configuring a multi-node vLLM server for DeepSeek-V4-Pro across 4 GPU servers (70.88, 70.93, 70.95, 70.96, each with 8×RTX 5090 32GB).

## Critical FP8 Block Quantization Constraint

DeepSeek-V4-Pro uses FP8 weight quantization with `weight_block_size: [128, 128]`. Every TP-split dimension **must be divisible by 128** (block_k).

Key model dimensions:
- `moe_intermediate_size`: 3072
- `hidden_size`: 7168
- `q_lora_rank`: 1536
- `n_shared_experts`: 1

Divisibility check:

| Dim | Value | TP=4 | TP=8 | TP=16 | TP=32 |
|-----|-------|------|------|-------|-------|
| moe_intermediate | 3072 | **768** ✅ | 384 ✅ | 192 ❌ | 96 ❌ |
| hidden_size | 7168 | **1792** ✅ | 896 ✅ | 448 ❌ | 224 ❌ |
| q_lora_rank | 1536 | 384 ✅ | **192** ❌ | 96 ❌ | 48 ❌ |

**Result:** TP=8 is the maximum viable TP size (per-node only). q_lora_rank=1536 fails at TP=8 with dividend 192. Actually wait — let me recheck. 1536/8=192, 192%128=64. So TP=4 is the true max.

Actually the working configs:
- **TP=4**: 3072/4=768 ✅, 7168/4=1792 ✅, 1536/4=384 ✅ — ALL pass
- **TP=2** also works
- **TP=1** works (no FP8 split)

## DP+EP Architecture (only way to use 4 nodes × 8 GPUs)

Since TP > 4 is blocked by FP8 constraints, to use all 32 GPUs you need: **TP=4, DP=4, EP enabled**.

```bash
# Architecture per node:
# TP=4 (4 of 8 GPUs used for tensor parallelism)
# DP=4 (1 replica per node, experts sharded across 16 TP×DP GPUs)
# EP enabled — 384 routed experts across all ranks
```

Each node runs its own API server. DP coordinator on head node (70.88).

## Memory Analysis

Model disk size: 806 GB (FP8 quantized with FP4 experts)
- Non-expert weights: ~20 GB BF16
- Shared experts per layer: 264 MB × 61 layers ≈ 16.1 GB
- Embeddings: ~3.7 GB
- Expert weights (FP4): 33 MB/expert/layer × 384 × 61 ≈ 774 GB
- Per EP rank (24 experts): ~48 GB (split across TP=4 GPUs → ~12 GB/GPU)

Each 32 GB GPU must hold: ~19 GB non-expert + ~12 GB expert = ~31 GB. Tight fit.

## CUDA OOM Mitigation

```bash
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
```

Lower `--gpu-memory-utilization` from 0.95 to 0.85.

Known OOM failure: allocating 504 MiB of FP4 expert weights fails when GPU has only 200 MiB free (non-expert weights filled 30.28 GB of 32 GB).

## Server Nodes

| IP | Hostname | Role | DP Rank |
|----|----------|------|---------|
| 10.10.70.88 | oem88 | Head | 0 |
| 10.10.70.93 | oem93 | Worker | 1 |
| 10.10.70.95 | oem95 | Worker | 2 |
| 10.10.70.96 | oem96 | Worker | 3 |

All servers: jianliu user, same password. Model at `/data/models/deepseekv4_pro/` (806 GB).
vLLM fork: `/data/vllm-ds4-sm120/` (jasl/vllm ds4-sm120 branch, v0.6.0.dev0).
Script path: `/data/venvs/vllm-ds4/start_dsv4_4node.sh`.
Python venv: `/data/venvs/vllm-ds4/`.

## Network

- NIC: ens20f0 @ 1 Gbps TCP (no RDMA — CX-6 Dx not connected)
- hostname resolves to 127.0.1.1 — must set env vars:
  ```bash
  export GLOO_SOCKET_IFNAME=ens20f0
  export TP_SOCKET_IFNAME=ens20f0
  export NCCL_SOCKET_IFNAME=ens20f0
  export NCCL_IB_DISABLE=1
  ```

## Known Failures

| Config | Failure | Root Cause |
|--------|---------|------------|
| TP=32, 4 nodes | FP8 block_k=128 | 3072/32=96 ❌ |
| TP=16, 2 nodes | FP8 block_k=128 | 3072/16=192 ❌ |
| TP=8 + DP=4 + EP | CUDA OOM | Non-expert + expert weights fill 32 GB |
| DP+EP worker disconnect | TCPStore connection to 127.0.0.1 | `--data-parallel-address` missing on head node |
