---
name: skill-library-maintenance
description: Governs how Hermes Agent creates, updates, and curates its own skill library. Embedding the user's mandate for active, continuous improvement rather than passive "nothing to save" defaults.
---

# Skill Library Maintenance

This umbrella skill governs the **meta-process** of maintaining the skill library itself. It does not govern any single domain skill; rather it defines **when** and **how** skill updates should be made by the agent.

## Why This Skill Exists

The user has identified that Hermes Agent was too frequently defaulting to "nothing to save" after complex tasks, missing learning opportunities. The core directive: **be active and scan for improvement in every session.**

## Update Mandate

**Every session must result in at least one skill evaluation.** A session ending without any skill activity is a missed learning opportunity, not a neutral outcome. Even tiny improvements count over time.

### Update Preference Order

When deciding where to save information discovered during a session:

1. **Patch a loaded skill** — If the session used a skill and you discovered a missing step, pitfall, wrong command, or improved approach, patch it immediately with `skill_manage(action='patch')`.
2. **Update an existing umbrella** — If the information fits under an existing skill but that skill wasn't loaded during the session, update it anyway.
3. **Create or update `skill-library-maintenance` references** — For meta-insights about skill management.
4. **Only skip after conscious evaluation** — A deliberate "no update needed" is fine, but requires checking the most relevant skill first.

### Examples of What Constitutes a Valid Update

- **Wrong command** in a skill: patch.
- **Outdated path** or environment change: patch.
- **Pitfall discovered** during execution: add to `### Pitfalls` section.
- **Verification step missing**: add.
- **OS-specific quirk** discovered: note it.
- **Better approach** found: update the workflow.
- **Even a single-line clarification** on ambiguous wording: patch.

### Always Scan For

- Are commands in the skill correct? (Test them mentally.)
- Are there unseen pitfalls the skill should warn about?
- Are there edge cases (OS differences, version differences) to document?
- Is the skill missing a trigger condition the user mentioned?
- Does the skill need a references/ note from this session?

## File Structure

```
~/.hermes/skills/hermes/skill-library-maintenance/
├── SKILL.md
└── references/
    ├── maintenance-mandate-2025.md       # Precedent: user's active-update instruction (2026-05)
    └── future-precedents.md              # Reserved for future explicit directives
```

## Conventions

- **Umbrella skill**: `skill-library-maintenance` is a class-level umbrella. Domain skills live under their own categories (devops/, productivity/, etc.).
- **References**: Add a `references/` note whenever the user gives an explicit meta-instruction about skills, so future sessions can discover the precedent without repeating the conversation.
- **Patching over replacement**: Use `skill_manage(action='patch')` (targeted `old_string` → `new_string`) for updates. Only use full `edit` for major rewrites. `patch` is less disruptive and preserves the skill's history.

## Pitfalls

- **Don't create narrow one-session skills.** The user prefers class-level umbrellas with rich SKILL.md + references/, not flat lists of narrow skills.
- **Don't skip update because it's small.** User explicitly said: "change is not small, it's a missed learning opportunity."
- **Don't wait to be asked.** The user wants proactive updates, not passive "should I save this?" questions.
- **Don't use memory for procedures.** Memory is for facts and preferences; skills are for procedures and workflows.

## Verification

After creating or updating a skill, verify:
1. `skill_view(name)` loads the updated content correctly.
2. The change addresses what was learned.
3. If updating existing content, the `old_string` is unique enough to match.
