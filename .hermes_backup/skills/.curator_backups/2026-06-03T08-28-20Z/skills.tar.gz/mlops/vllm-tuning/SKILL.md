---
name: vllm-tuning
description: Use when tuning vLLM serving parameters for throughput and TTFT optimization on multi-node GPU clusters. Covers DeepSeek V4 Pro on RTX PRO 6000 Blackwell (96GB/card) with TP/DP/EP/PP configurations, batched-tokens/seqs tuning, prefix caching, compilation strategies, and vllm bench serve methodology.
version: 1.2.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [vllm, serving, throughput, ttft, tuning, deepseek, blackwell, distributed]
    related_skills: [remote-server-management, model-deployment]
---

# vLLM Serving Tuning

Umbrella skill for tuning vLLM server parameters to optimize throughput and TTFT on multi-node GPU clusters, specifically DeepSeek V4 Pro on RTX PRO 6000 Blackwell SE (96GB/card).

## When to Use

- User asks to improve vLLM serving performance (throughput, TTFT, TPOT)
- Deploying DeepSeek models on multi-node clusters with TP/DP/EP/PP
- Running vllm bench serve for systematic comparison
- Diagnosing vLLM startup failures (DP handshake timeouts, OOM, port conflicts)
- Testing prefix caching effectiveness

## Cluster Environment

- **Model**: DeepSeek V4 Pro (~806GB total, fp8 quantized)
- **Nodes**: 70.96 (master) + 70.98 (worker), 8× RTX PRO 6000 Blackwell SE (96 GB/card) each
| **Interconnect** | RoCE v2 over ConnectX-6 Dx 100GbE via LACP bond (bond0, MTU 9000) |
- **NCCL**: IB Verbs via mlx5_0, GID index 3, timeout 23, TC 136
- **vLLM**: github.com/jasl/vllm ds4-sm120 branch (v0.6.0.dev0)
- **Model path**: /data/models/deepseekv4_pro
- **Venv**: /data/venvs/vllm-ds4

---

## References

See linked files for detailed information:

- `references/benchmark-methodology.md` — Standard test suite (S1/S2/S3), warmup requirements, metric interpretation
- `references/tuning-matrix.md` — Empirical results for all tested configurations. Actual TTFT/TPOT/throughput numbers. Best general-purpose: 8192/512 (Phase 2.5)
- `references/dp-handshake-timeout.md` — Root cause analysis and workarounds for the 5-minute DP handshake timeout in ds4-sm120 branch
- `references/pp-configuration.md` — PP=2 across 2 nodes: confirmed WORKING with VLLM_HOST_IP + NCCL RoCE v2. See Strategy Selection section for details.
- `references/memory-budget.md` — GPU memory estimation for DeepSeek V4 Pro on 96GB Blackwell cards
- `references/multi-node-dp-debugging-session.md` — Full debugging session log: --api-server-count+headless conflict, ZMQ port persistence, zombie VLLM:: cleanup
- `references/nccl-blackwell-compat.md` — NCCL 2.28.9 incompatibility with Blackwell sm120: error signature, fix (copy system 2.30.4 into venv), verification steps
- `scripts/startup-master.sh` — Template startup script for master node (DP mode)
- `scripts/startup-worker.sh` — Template startup script for worker node (DP mode)
- `scripts/startup-master-pp.sh` — Template startup script for master node (PP mode)
- `scripts/startup-worker-pp.sh` — Template startup script for worker node (PP mode)
- `scripts/bench-all.sh` — Run S1+S2+S3 in sequence with a single command

---

## Strategy Selection

When deploying on 2 nodes with ds4-sm120 branch (v0.6.0.dev0), both strategies work, but PP=2+EP=8 is STRONGLY preferred when the correct NCCL env is set:

| Strategy | Parameters | Cross-Node? | Status |
|----------|-----------|------------|--------|
| **TP+PP+EP** | TP=8, PP=2, EP=8 | **Yes** (NCCL RoCE v2) | ✅ **Preferred**. Dramatically better prefix cache. |
| **TP+DP+EP** | TP=8, DP=2, EP=16 | Yes (DP coordinator) | ✅ Works. More complex handshake. |

### PP=2 DOES work across 2 nodes

The proven configuration is in the existing script at `/data/venvs/vllm-ds4/start_dsv4_pro_2node.sh` on node 70.96.

**Key difference from naive attempt**: The multiproc executor defaults to `127.0.0.1` for distributed_init_method. PP across nodes requires the **`VLLM_HOST_IP`** env var to be set on each node:

```bash
# Master (70.96):
export VLLM_HOST_IP="10.10.71.96"

# Worker (70.98):
export VLLM_HOST_IP="10.10.71.98"
```

Plus the full NCCL RoCE v2 configuration (see the proven script for exact values). With these env vars, the NCCL workers discover each other across nodes correctly.

**PP=2 also still requires `--nnodes 2`, `--node-rank <0|1>`, and `--master-addr`/`--master-port`** — these set up the TCPStore for distributed initialization.

### PP vs DP: Prefix Cache is Decisively Better

**UPDATE (2026-05-26): Clean comparison with both on max-model-len=1M at 8192/128:**

| Metric | DP (8192/128) | **PP (8192/128)** | Improvement |
|--------|--------------|-------------------|-------------|
| S1 TTFT | 12.69s | **5.92s** | 53% faster |
| S2 60K TTFT | 260.5s | **188.8s** | 28% faster |
| S3 prefix TTFT | 142.8s | **43.2s** | **69% faster** |
| S3 throughput | 4.14 tok/s | **7.73 tok/s** | 87% more |
| S1 throughput | 48.2 tok/s | **67.4 tok/s** | 40% more |
| S1 TPOT | 108.6ms | **102.8ms** | 5% faster |

PP wins on EVERY metric. DP also crashed on 2/3 benchmarks with 8192/512 (API server OOM during long prompt decode), while PP completed 5/6 configs stably.

**Why PP beats DP for this setup:**
1. **PP coordinator is simpler**: DP requires a ZMQ coordinator process with 5-minute handshake timeout plus a DP coordinator process. Any failure on the worker side (OOM, config conflict) causes a cascading 5-minute stall.
2. **EP=8 vs EP=16**: PP uses half the expert parallelism, reducing expert routing table memory by ~40%, leaving more room for KV cache.
3. **Pipeline parallelism shares KV cache**: PP splits model layers across nodes, so each node only needs KV cache for its pipeline stage — less memory pressure per GPU.
4. **EP=16 with DP=2 fragments memory**: Each expert requires a routing table per node. With 16 experts × 2 DP ranks, that's 32 tables vs PP's 8 experts × 1 rank = 8 tables.

**Recommendation: PP is the default choice. Only consider DP if you have a specific reason the DP coordinator pattern is required.**

See `references/tuning-matrix.md` for complete results.

If DP handshake fails, the correct diagnosis path is in `references/dp-handshake-timeout.md`.

---

## Startup Scripts (Master, 70.96)

```bash
#!/bin/bash
# TP=8 + DP=2 + EP=16, batched-tokens=<B>, seqs=<N>
cd /data/venvs/vllm-ds4
source ~/.bashrc
source /data/venvs/vllm-ds4/bin/activate
rm -f /tmp/vllm_tp8_dp2.log
/usr/bin/nohup /data/venvs/vllm-ds4/bin/python3.12 /data/venvs/vllm-ds4/bin/vllm serve \
  /data/models/deepseekv4_pro --host 0.0.0.0 --port 8000 --trust-remote-code \
  --distributed-executor-backend mp --tensor-parallel-size 8 --pipeline-parallel-size 1 \
  --data-parallel-size 2 --data-parallel-size-local 1 --data-parallel-backend mp \
  --data-parallel-address 10.10.71.96 --nnodes 2 --node-rank <0|1> \
  --master-addr 10.10.71.96 --master-port 29505 --data-parallel-rpc-port 29550 \
  --enable-expert-parallel --kv-cache-dtype fp8 --block-size 256 \
  --max-model-len 1048576 --gpu-memory-utilization 0.93 \
  --max-num-seqs <N> --max-num-batched-tokens <B> \
  --compilation-config '{"mode":3,"cudagraph_mode":"FULL_AND_PIECEWISE",\
    "compile_ranges_endpoints":[8192,16384,<B>]}' \
  --tokenizer-mode deepseek_v4 --tool-call-parser deepseek_v4 \
  --enable-auto-tool-choice --reasoning-parser deepseek_v4 \
  --served-model-name deepseek_v4_pro > /tmp/vllm_tp8_dp2.log 2>&1 &
echo "PID:$!"
```

**Worker (70.98)**: Same command with `--headless --node-rank 1`.  
**Start order**: Worker FIRST, then master.  
**CRITICAL**: DO NOT put `--api-server-count 1` on the headless (--node-rank 1) node — it crashes with `ValueError: --api-server-count=1 cannot be used with --headless`. Only the master node (rank 0) gets `--api-server-count`.  
**PP mode**: Use `--pipeline-parallel-size 2` instead of `--data-parallel-*` flags. PP mode still requires `--nnodes 2`, `--node-rank <0|1>`, `--master-addr`/`--master-port`, and critically the **`VLLM_HOST_IP`** env var set to each node's real IP (10.10.71.96 for master, 10.10.71.98 for worker). PP also needs the full NCCL RoCE v2 configuration (NCCL_IB_HCA=mlx5_0, NCCL_NET=IB). See the proven script at `/data/venvs/vllm-ds4/start_dsv4_pro_2node.sh` and `scripts/startup-master-pp.sh`/`scripts/startup-worker-pp.sh` for correct PP templates.

**The proven script at `/data/venvs/vllm-ds4/start_dsv4_pro_2node.sh`** is the reference PP startup. It includes the exact NCCL env vars (NCCL_IB_HCA=mlx5_0, NCCL_IB_GID_INDEX=3, NCCL_IB_TIMEOUT=23, NCCL_IB_QPS_PER_CONNECTION=4, NCCL_IB_TC=136, NCCL_CROSS_NIC=0, NCCL_ALGO=Ring, NCCL_MIN_NCHANNELS=8, NCCL_NET=IB), VLLM_HOST_IP per-node, and the `-cc.pass_config.fuse_allreduce_rms=False` flag. The script uses `2>&1 | tee -a` (foreground pipe) so it blocks — run in background or a separate terminal. It logs to `/tmp/vllm_$1.log` where $1 is "master" or "worker".

For PP mode, **worker and master can start in either order** (both connect via TCPStore on 10.10.71.96:29505). The worker uses `--headless`.

**Worker start order for DP**: Worker FIRST, then master.

---

## PP vs DP: Apples-to-Apples (max-model-len=1M, 8192/128)

The cleanest comparison — both strategies completed all 3 benchmarks at max-model-len=1M:

| Metric | DP (TP=8+DP=2+EP=16) | **PP (TP=8+PP=2+EP=8)** | PP Advantage |
|--------|----------------------|-------------------------|--------------|
| S1 TTFT | 12.69s | **5.92s** | **2.1× faster** |
| S1 TPOT | 108.6ms | **102.8ms** | **5.3% better** |
| S1 throughput | 48.2 tok/s | **67.4 tok/s** | **40% more** |
| S2 60K TTFT | 260.5s | **188.8s** | **28% faster** |
| S3 prefix TTFT | 142.8s | **43.2s** | **3.3× faster** |
| S3 TPOT | 93.2ms | **81.0ms** | **13% better** |
| S3 throughput | 4.14 tok/s | **7.73 tok/s** | **87% more** |

**PP wins decisively.** DP also crashed on larger configs (8192/512 OOM on S2/S3), while PP completed 5 configs stably.

**Recommendation: Always use PP=2 unless you have a specific reason for DP.** See `references/pp-configuration.md` for required VLLM_HOST_IP + NCCL RoCE v2 setup.

See `references/tuning-matrix.md` for complete results.

## Key Hyperparameter Tuning Results

### PP mode (TP=8+PP=2+EP=8) — strongly preferred

| Config | S1 TTFT | S1 TPOT | S1 tok/s | S2 60K TTFT | S3 prefix TTFT | S3 TPOT | S3 tok/s |
|--------|---------|---------|----------|-------------|----------------|---------|----------|
| **8192/512** | **2.2s** | 99.7ms | 86.2 | 186.7s | 44.4s | 60.7ms | 7.15 |
| 8192/128 | 5.9s | 102.8ms | 67.4 | 188.8s | **43.2s** | 81.0ms | **7.73** |
| 8192/256 | **3.3s** | 105.5ms | 76.5 | **182.3s** | **43.9s** | 98.1ms | 7.41 |
| 16384/256 | 16.0s | 102.8ms | 44.0 | 197.5s | 48.5s | 56.4ms | 5.15 |
| 16384/128 | 16.3s | 102.4ms | 43.6 | 226.3s | 49.0s | 67.3ms | 7.08 |
| 16384/512 | **1.4s** | 99.5ms | **91.3** | (crashed) | (crashed) | — | — |

**Recommendation**: PP=2 at **8192/512** for general purpose. Use **8192/128** or **8192/256** for prefix-heavy workloads.

### DP mode (TP=8+DP=2+EP=16) — limited, only 8192/128 completed all 3 benchmarks at max-model-len=1M

| Config | S1 TTFT | S1 TPOT | S1 tok/s | S2 60K TTFT | S3 prefix TTFT | Status |
|--------|---------|---------|----------|-------------|----------------|--------|
| 8192/128 | 12.7s | 108.6ms | 48.2 | 260.5s | 142.8s | ✅ Only fully stable DP config |
| 8192/512 | 2.6s | 99.3ms | 83.9 | (crashed) | (crashed) | ⚠️ S1 only |

**Note on larger configs**: 32768+ batched-tokens or 512+ seqs at 16384+ batch all OOM on 96GB/card Blackwell due to KV cache pre-allocation exceeding 5-6 GiB available after model weights. DP=2 with EP=16 consumes more memory than PP=2 with EP=8, making DP less viable for 1M context.

**See `references/tuning-matrix.md`** for complete empirical data with per-config TTFT/TPOT/throughput figures.

---

## Critical Pitfall: Multi-Node Startup — Wrong IPs / RDMA Device Names

When starting a 2-node PP or DP cluster between 70.96 and 70.98, the startup scripts may reference IPs that do not exist:

- **10.10.71.x IPs do not exist** — No interface on either node has `10.10.71.96/98`. The actual RDMA IPs on bond0 are `192.168.66.10` (96) and `192.168.66.20` (98). Bon addresses in HEAD_IP, VLLM_HOST_IP, and MASTER_ADDR must use these.
- **GLOO needs an interface WITH an IP** — Setting `GLOO_SOCKET_IFNAME=ens35f0np0` (bond slave) causes `Unable to find address for: ens35f0np0` because the slave has no IP. Use `GLOO_SOCKET_IFNAME=bond0` which holds the actual IP.
- **RDMA device name differs per node** — On 70.96 the RDMA device is `rocep200s0f0`, on 70.98 it is `mlx5_bond_0` (due to RDMA bonding). If NCCL_IB_HCA=rocep200s0f0 is fixed in the script, it fails on 98 with `Failed to initialize any NET plugin`. Fix: auto-detect at runtime: `RDMA_DEV=$(rdma link show | head -1 | awk '{print $2}' | sed 's,/.*,,')`.

Also note: IPC ZMQ bind errors (`Cannot assign requested address`) when the VLLM_HOST_IP is not a local address — vLLM's ZMQ-based inter-process communication binds to VLLM_HOST_IP, so it must be a local interface IP.

## Critical Pitfall: Port 29505 Held by Zombie Workers After Crash

When vLLM crashes during startup (after worker processes have connected via TCPStore on port 29505), zombie `VLLM::Worker_PP*` processes can survive and continue holding port 29505 open. Subsequent restart attempts fail with:

```
DistNetworkError: The server socket has failed to listen on any local network address.
port: 29505, useIpv6: false, code: -98, name: EADDRINUSE
```

The zombie processes may not show up in a standard `ps aux | grep vllm` because their process names contain `VLLM::` prefix, not `vllm`:

```bash
# Check for survivors:
ps aux | grep VLLM::
ss -tlnp | grep 29505   # shows which PID holds the port

# Kill them:
kill -9 <PID>
```

**Best practice on restart**: Always check port 29505 before launching:

```bash
ss -tlnp | grep 29505 && echo "PORT IN USE - kill zombies first" || echo "port free"
```

## Critical Pitfall: MLA Models Do Not Work on Blackwell (CC 12.0)

This affects any model using **Multi-head Latent Attention (MLA)** — including DeepSeek V2/V3/V4 variants and **GLM-5.1-FP8** (GlmMoeDsaForCausalLM) — when deployed on Blackwell GPUs (RTX PRO 6000, compute capability 12.0).

### Blackwell CC 12.0 Issues Beyond Attention Backend Selection

Even after patching compute capability checks (see `references/blackwell-mla-patches.md`), other issues emerge:

**1. Triton MLA shared memory limit**: Blackwell SM 12.0 has 99 KB shared memory per block. The Triton MLA decode kernel requests 100 KB (102400 vs hardware limit 101376). Must use `--enforce-eager` to avoid CUDA graph warmup triggering the decoder kernel. Some batch sizes may still hit this at runtime.

**2. TRITON_MLA is the only working backend after patching**:
- `FLASHINFER_MLA` → XQA kernel requires 128 query heads/GPU (models with 64 heads + TP=8 have only 8/GPU)
- `CUTLASS_MLA` → does not support DECODER attention type
- `FLASHMLA` → `vllm._flashmla_C` not compiled for CC 12.0
- `FLASHINFER_MLA_SPARSE` → 3D page table vs 2D layout required by HND format
- **`TRITON_MLA`** → works with `--enforce-eager --block-size 64 --kv-cache-dtype auto`.
  > **`--kv-cache-dtype fp8` crashes**: Triton kernel `_fwd_grouped_kernel_stage1` requests
  > 100 KB shared memory, Blackwell SM 12.0 limit is 99 KB (101,376 bytes). Always use `auto`.

**3. Forcing non-sparse mode**: Models with `index_topk` in config.json trigger `is_v32=True` → `use_sparse=True`, which disables TRITON_MLA (sparse not supported). Fix: patch `deepseek_v2.py` lines 985/1216:
```python
self.is_v32 = hasattr(config, "index_topk") and getattr(config, "index_topk", 0) > 0
```
Then pass `--hf-overrides '{"index_topk": 0}'` at startup.

**4. Indexer FP8 weight fusion (GLM-specific)**: GLM checkpoints store indexer `wk.weight` + `wk.weight_scale_inv` as FP8. vLLM's `_try_load_fp8_indexer_wk` dequantizes into a fused `wk_weights_proj.weight` param. Three patches needed in `deepseek_v2.py`:
- Before `_try_load_fp8_indexer_wk`: `if not hasattr(self, "indexer") or (self.indexer is None and "indexer" in name): continue`
- Guard `params_dict[fused_name]` with `if fused_name not in params_dict: return False`
- Patch `is_v32` (point 3 above) so sparse is disabled and indexer isn't built

**5. GLM requires transformers v5**: The `glm_moe_dsa` model type is unrecognized by transformers v4.x:
```bash
pip install --upgrade 'transformers>=5.4.0'```

**6. Corrupt safetensors over nc/tar**: When transferring large checkpoints between nodes via `tar | nc`, shard files can be silently truncated. Verify all shards:
```python
from safetensors import safe_open
for f in sorted(glob.glob("model-*.safetensors")):
    with safe_open(f, "pt") as s: pass  # raises if corrupt
```

**Symptom**: vLLM engine initialization fails with:
```
ValueError: No valid attention backend found for cuda with AttentionSelectorConfig(
  head_size=576, dtype=torch.bfloat16, kv_cache_dtype=fp8, block_size=256,
  use_mla=True, ...
). Reasons: {
  FLASH_ATTN_MLA: [compute capability not supported, ...],
  FLASHMLA: [compute capability not supported, ...],
  FLASHINFER_MLA: [compute capability not supported, ...],
  TRITON_MLA: [sparse not supported],
  FLASHMLA_SPARSE: [compute capability not supported]
}
```

**Root cause**: All MLA attention backends in the `ds4-sm120` branch restrict compute capability to major version 9 (Hopper) or 10 (Blackwell v1). For example, `FlashMLABackend.supports_compute_capability` returns `capability.major in [9, 10]` — Blackwell CC 12 is excluded.

Additionally, models with `index_topk` in config.json (like GLM-5.1-FP8) trigger **sparse MLA** (`is_sparse=True`), which further limits backend choices since `TritonMLABackend` (the only CC-agnostic backend) does not support sparse mode.

**Fix**: Patch 8 files in the vLLM source + clear Python bytecode cache. See `references/blackwell-mla-patches.md` for the exact diff and patching procedure.

**No CLI flag workaround exists**: `use_sparse=True`, `kv_cache_dtype=fp8`, and `use_mla=True` are all auto-detected from the model config. There is no `--disable-mla` or `--disable-sparse` flag in the ds4-sm120 branch.

**Second blocker**: After passing the attention backend, GLM-5.1-FP8 weight loading fails with `KeyError: 'model.layers.39.self_attn.indexer.wk_weights_proj.weight'` — the FP8 indexer weight fusion path doesn't handle GLM's checkpoint layout. See `model-deployment` skill's `references/glm5-multi-node.md` for details.

**6. KV Cache dtype must match Blackwell expectations**: TRITON_MLA on Blackwell with --kv-cache-dtype auto (bf16) triggers a FlashInfer XQA MLA fallback that rejects non-fp8 inputs. Always use --kv-cache-dtype fp8 with TRITON_MLA on Blackwell.

**7. Garbled output with GLM (2026-06-02 root cause update)**: The garbled output is NOT a tokenizer issue.
Standalone `AutoTokenizer.decode()` and vLLM's `get_tokenizer().decode()` both return correct text.
The root cause is the **model forward pass producing near-random logits** (logprob ≈ -11.95 per token,
uniform over ~155K vocab). Model weights are intact (embedding std 0.009, bf16). Hypothesis:
`--hf-overrides '{\"index_topk\": 0}'` forces `is_v32=False`, which may collapse MoE expert routing
to random selection. Next step: test without `index_topk: 0` override or with `force_dense_mla` only.
See `glm5-fp8-blackwell` skill's `references/model-logits-debugging.md` for full evidence.

## Critical Pitfall: NCCL "unhandled system error" on Blackwell (sm120)

On NVIDIA RTX PRO 6000 Blackwell SE (compute capability 12.0), NCCL 2.28.9 can produce a persistent `RuntimeError: NCCL error: unhandled system error` during `PyNcclCommunicator.__init__` → `self.all_reduce(data)` (line 142 of `pynccl.py`).

**Symptoms:**
- All 8 workers on the master node fail simultaneously with the same error
- Happens during `init_worker_distributed_environment` → `initialize_model_parallel` → `PyNcclCommunicator.__init__`
- IB link is ACTIVE (cat `/sys/class/infiniband/mlx5_0/ports/1/state` returns 4: ACTIVE)
- No zombie processes, no port conflicts, all GPUs idle
- Error persists across repeated kill/restart cycles
- Often triggered after repeated vLLM process kills (crash-loop scenario)
- Affects BOTH PP and DP modes — the NCCL all-reduce during communicator init is strategy-independent
- The error occurs on the master node ONLY (70.96). The worker (70.98) passes NCCL init fine.
- Once triggered, it persists across all subsequent restart attempts until a GPU reset

**Root cause:** Likely NCCL communicator state corruption on Blackwell after repeated process termination. The `nvidia_uvm` kernel module or NVLink bridge on sm120 may leave NCCL peers in a bad state after kill -9. The error originates from `cuda_communicator.py:75` → `PyNcclCommunicator.__init__` → `self.all_reduce(data)` — this is the first cross-GPU NCCL communication during init, and on Blackwell (sm120) the NCCL 2.28.9 runtime doesn't handle the stale peer state gracefully.

On these servers, gdm3 (GNOME Display Manager) runs Xorg, which also holds a GPU context, so `fuser` and `ps aux` may report no vLLM processes but the GPUs are still "in use by another client" from GDM's graphics session. Running `sudo systemctl stop gdm3` before `nvidia-smi -r` is required.

**Mitigations (in order of effectiveness):**
1. **Stop gdm3 then GPU reset** (requires root):
   ```bash
   sudo systemctl stop gdm3         # release GPU from X server
   sudo nvidia-smi -r              # reset all GPUs
   ```
   This is the ONLY reliable fix. System reboot also works.
2. **Temporary NCCL TCP fallback**: Set `NCCL_IB_DISABLE=1` and `NCCL_NET=Socket` to bypass IB verbs. This works but uses TCP over the 100GbE link instead of RDMA. Performance degrades significantly (especially for TP cross-node all-reduce).
3. **Increase idle time between kills**: Wait 10-15 seconds after all processes are dead and GPUs show 14 MiB before restarting. Sometimes the NCCL state self-recovers given sufficient idle time.
4. **Check for zombie VLLM:: processes**: `ps aux | grep VLLM::` — if any survive, kill them explicitly before restarting

**Note:** TCP fallback can be used to confirm the service starts correctly (NCCL initialization passes with Socket backend). The IB error is a system/NCCL state issue, not a configuration issue. After a successful reset + restart, restore IB backend and it works again.

**After GPU reset, gdm3 auto-restarts** (systemd will respawn it). The X server will re-initialize on the GPUs, which takes ~10-15s. Don't rush — wait for nvidia-smi to show steady 14 MiB per GPU before starting vLLM.

### NCCL 2.28.9 incompatibility with Blackwell (sm120) — "invalid usage" on ncclCommInitRank

After GPU reset, a different NCCL error can appear:
```
RuntimeError: NCCL error: invalid usage (run with NCCL_DEBUG=WARN for details)
```
This error occurs at `pynccl.py:135` → `ncclCommInitRank` — different from the `unhandled system error` above. The root cause is **NCCL 2.28.9 does not support Blackwell (compute capability 12.0)**.

**Environment**:
- System NCCL: 2.30.4 (`libnccl2` package, installed via apt)
- Venv NCCL (via PyTorch / nvidia-nccl-cu130 wheel): 2.28.9
- CUDA driver: 595.58.03, CUDA 13.2
- GPU: RTX PRO 6000 Blackwell SE (sm120)

**Fix** — copy the system NCCL .so into the venv:
```bash
# On each node:
cp /usr/lib/x86_64-linux-gnu/libnccl.so.2.30.4 \
  /data/venvs/vllm-ds4/lib/python3.12/site-packages/nvidia/nccl/lib/libnccl.so.2
cp /usr/lib/x86_64-linux-gnu/libnccl.so.2.30.4 \
  /data/venvs/vllm-ds4/lib/python3.12/site-packages/torch/lib/libnccl.so.2.30.4
cd /data/venvs/vllm-ds4/lib/python3.12/site-packages/torch/lib
ln -sf libnccl.so.2.30.4 libnccl.so.2
```

**Verification**: Start vLLM and check the log line:
```
vLLM is using nccl==2.30.4
```

If it still says `2.28.9`, the symlink was wrong. Verify with:
```bash
/data/venvs/vllm-ds4/bin/python3 -c "
from vllm.distributed.device_communicators.pynccl_wrapper import *
import ctypes, os
# Check which libnccl is actually loaded
print(os.path.realpath(ctypes.util.find_library('nccl')))
"

## Critical Pitfall: DP Handshake Timeout

ds4-sm120 branch (v0.6.0.dev0) has a **hardcoded 300s timeout** in `core.py:1046` for `DPEngineCoreProc.startup_handshake`. When the remote (headless) node fails to start its engine core, the master waits 5 minutes before timing out.

Most failures labelled "handshake timeout" are actually other issues:

**Pitfall 1: `--api-server-count 1` conflicts with `--headless`**
```
ValueError: --api-server-count=1 cannot be used with --headless
(no API servers are started in headless mode).
```
The headless worker node crashes at startup. Master then waits 5 minutes for a remote HELLO that will never arrive. **Fix**: Do NOT put `--api-server-count 1` on the headless (--node-rank 1) node.

**Pitfall 2: ZMQ port conflict (29550)**
```
ZMQError: Address already in use (addr='tcp://10.10.71.96:29550')
```
Previous vLLM processes leave the ZMQ port in TIME_WAIT. `fuser -k` may not catch it. **Fix**: `ss -tlnp | grep 29550` to confirm it's gone; if still present, `fuser -k 29550/tcp`.

**Pitfall 3: Zombie VLLM:: named processes hold CUDA memory**
After killing a vLLM host process, subprocesses named `VLLM::EngineCore_DP1`, `VLLM::Worker_DP1_TP*` may survive holding GPU memory. **Fix**: `ps aux | grep VLLM | awk '{print $2}' | xargs kill -9`

---

## /etc/hosts Pitfall (Ubuntu)

Ubuntu maps hostname to `127.0.1.1` by default. This causes Gloo to bind to loopback, breaking cross-node communication:

```bash
sudo sed -i '/<hostname>/d' /etc/hosts
echo '<real-ip>  <hostname>' | sudo tee -a /etc/hosts
```

---

## Benchmark Tips

- `--random-input-len` not `--input-len` for random dataset
- `--random-output-len` not `--output-len`
- `--backend openai-chat --endpoint /v1/chat/completions`
- `--tokenizer /data/models/deepseekv4_pro` (local path, not HF)
- `HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1`
- Always warm up (1 request) before measuring
- Prefix cache gives ~47% TTFT improvement on shared prefixes (in ds4-sm120)
- Cold first request includes JIT compilation penalty (~3-6s)

---

## Verification Checklist

- [ ] SSH passwordless auth between nodes
- [ ] `/etc/hosts` maps to real IP
- [ ] Stale Python processes killed, ports 29505/29550 free
- [ ] GPU memory fully released (check for VLLM:: zombies)
- [ ] --api-server-count NOT set on headless node
- [ ] Worker started BEFORE master
- [ ] S1 warm-up run completes
- [ ] Prefix caching confirmed working (S3: ~47% expected over S2)
- [ ] Compile ranges match batched-tokens
