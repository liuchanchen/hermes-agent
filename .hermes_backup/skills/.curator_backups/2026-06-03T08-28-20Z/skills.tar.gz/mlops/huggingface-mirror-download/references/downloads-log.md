# Model Downloads Log — hf-mirror.com

Running log of models downloaded via this skill, updated per session.

---

## nvidia/GLM-5.1-NVFP4

- **Downloaded:** 2026-06-03
- **Target server:** 10.10.70.96 (oem96)
- **Target path:** `/data/models/glm_5_1_nvfp4/`
- **Total size:** 465.9 GB
- **Files:** 59 (49×safetensor shards + config/tokenizer/metadata)
- **CLI:** `/data/venvs/vllm-ds4/bin/hf` (hf-hub 1.17.0)
- **Started via:**
  ```bash
  # CORRECT: setsid (survived 3.5+ hours)
  ssh jianliu@10.10.70.96 "source ~/.bashrc && mkdir -p /data/models/glm_5_1_nvfp4 && \
    setsid env HF_ENDPOINT=https://hf-mirror.com \
      /data/venvs/vllm-ds4/bin/hf download nvidia/GLM-5.1-NVFP4 \
      --local-dir /data/models/glm_5_1_nvfp4 --repo-type model --max-workers 2 \
      </dev/null >/dev/null 2>&1"
  # PID 309547 (stable, 22% CPU)

  # WRONG pattern (died silently — DO NOT USE):
  ssh jianliu@10.10.70.96 "nohup env HF_ENDPOINT=... hf download ... &"
  # The & at SSH command level causes process death within minutes.
  ```
- **Log:** `/tmp/hf_download_glm5_nvfp4.log`
- **Measured rate:** ~20 MB/s (~5–6 GB per 5 min)
- **Network note:** huggingface.co direct blocked (curl timeout 28), hf-mirror.com works via proxy `http://10.10.60.140:7890`
- **Download progress:**
  - 10:40 → first attempt (nohup) — died within 40 min
  - 11:16 → second attempt (nohup) — died again
  - 11:31 → third attempt (nohup) — died again
  - 12:30 → fourth attempt (**setsid**) — survived stably
  - 13:00 (1h later): 104 GB, 10/49 shards
  - 14:00 (2h later): 160 GB, 16/49 shards
  - 15:00 (3h later): 197 GB, 21/49 shards
- **Status at session end:** 21/49 shards done, 197 GB / 465.9 GB, download still active (PID 309547).
  Est. remaining: ~270 GB → ~5–6 more hours.

---

## Adding entries

Append a new section per model. Include: repo ID, date, server, path, total size, command used (setsid version), log path, measured speed, and status.