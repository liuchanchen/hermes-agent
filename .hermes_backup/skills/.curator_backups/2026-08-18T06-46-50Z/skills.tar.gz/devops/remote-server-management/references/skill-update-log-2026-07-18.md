# Skill Library Update: 2026-07-18

## Updated

### `devops/internal-gpu-node-12-12` → v0.5.0

**What changed:**
- Corrected SSH password from `0` → `qs@2024.local` (previous `0` was broken)
- Added SSH key bootstrap pattern (70.96 → 12.12 passwordless via authorized_keys)
- Added full hardware info: 8× H100 80GB, driver 580.95.05, vLLM v0.20.0
- Added GPU monitoring dashboard on port 8080 (data/snapshots/*.json)
- Added model inventory: `/home/public/models/` has 150+ model dirs, including Qwen3.5-397B, MiniMax M2.7, DeepSeek R1 variants
- Added GLM-5.2-NVFP4 copy-in-progress status with screen monitoring command
- Added network bottleneck note: 70.96↔12.12 only 10 Mbps, use shared NAS as intermediary
- Removed the previous stale entry about "no /data/models/ on 12.12" (incorrect — /mnt/data3/public/models/ exists)
- Secondary port 51653 documented as dead (connection reset)

### `devops/remote-server-management`

**What changed (2026-07-31):**
- **Discovered 10.10.70.90** (warp-Bumblebee-BI5284): 2× RTX PRO 6000 Blackwell SE (10de:2bb9), Xeon Platinum 8558P (48c, 260MB L3), 7TB NVMe, NCCL 2.30.7+cuda13.3, NVML mismatch (595.71.05 kernel vs 595.84 lib — reboot needed), jianliu password broken (use qs/!QAZ2wsx). Private registry 10.10.91.56 with WarpDrive vLLM images. Models: gemma-4-31B-it, Qwen3-32B, Qwen3.6-35B-A3B-FP8/NVFP4, Qwen3-8B at `/data/home/public/models/tgu01/`.
- Added 70.90 to Supported Servers table
- Added 70.90 column to Model Inventory with its local model paths
- Added 70.90 row to Known Server Configs (bare node, no vLLM running)
- Created `references/70-90-initial-setup.md` — full discovery details
- Created `devops/server-discovery-update` skill — procedural workflow for future server discovery rounds
- **2026-07-27:** 70.88 live check: Qwen3.6-35B-A3B-NVFP4 PD Disaggregation running
- **2026-07-23:** Added 10.10.70.99 (oem-99, WarpDrive TGU01-Pro)
- Added 70.99 column to Model Inventory

## Created

### `devops/update-node-12-12-password`

Password-change skill for 192.168.12.12. Covers the exact chpasswd command through sshpass via jump host, with pitfalls for shell-special characters and !QAZ2wsx history expansion.

## Not changed

The existing `remote-server-management` reference `nas-intermediary-transfer.md` covers the generic NAS-as-intermediary pattern. The new `cross-node-model-transfer.md` is a sibling focused specifically on the 70.96↔12.12 case with concrete bench numbers and the screen-rsync procedure. These are complementary.
