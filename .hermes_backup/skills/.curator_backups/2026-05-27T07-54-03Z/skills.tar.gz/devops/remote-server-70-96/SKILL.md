---
name: remote-server-70-96
description: Remote GPU server management for 10.10.70.96 (oem96) — 8× NVIDIA RTX 5090 (32GB each), DeepSeek-V4-Pro master node, LVM storage, proxy access, SSH and operations.
version: 1.0.0
author: Hermes Agent
license: MIT
---

# Remote Server 10.10.70.96 — NVIDIA RTX 5090

## Access

```bash
ssh jianliu@10.10.70.96
```

| Field | Value |
|-------|-------|
| **Username** | jianliu |
| **IP (management)** | 10.10.70.96 |
| **IP (100G)** | 10.10.71.96 |
| **Password** | !QAZ2wsx |
| **Sudo Password** | !QAZ2wsx (same as login) |

> **Important:** This server has a proxy (`http://10.10.60.140:7890`) configured in `~/.bashrc`. Non-interactive SSH does NOT load `.bashrc` automatically. **Always prefix remote commands with `source ~/.bashrc &&`**.

### SSH Patterns

```bash
# Non-interactive command (most common)
ssh jianliu@10.10.70.96 "source ~/.bashrc && command"

# Sudo commands — use SUDO_ASKPASS helper (sudo -S piped password is blocked)
ssh jianliu@10.10.70.96 'cat > /tmp/spwd_helper.sh << '\''EOF'\''
#!/bin/bash
echo "!QAZ2wsx"
EOF
chmod 700 /tmp/spwd_helper.sh
SUDO_ASKPASS=/tmp/spwd_helper.sh sudo -A <command>; rm -f /tmp/spwd_helper.sh'

# SCP / file transfer
scp local_file jianliu@10.10.70.96:/path/to/dest/
```

## Hardware Specs

| Component | Detail |
|-----------|--------|
| **Hostname** | oem96 |
| **IP (management)** | 10.10.70.96 on `ens20f0` (Intel I350 1GbE) |
| **IP (high-speed)** | 10.10.71.96/24 on `ens35f0np0` (ConnectX-6 Dx 100GbE) |
| **GPU** | 8× NVIDIA RTX PRO 6000 Blackwell Server Edition |
| **GPU Memory** | 97,887 MiB (~96 GB) each (768 GB total) |
| **Compute Capability** | 12.0 (Blackwell) |
| **Driver** | 595.58.03 |
| **CUDA Driver** | 13.2 |
| **CPU** | Intel Xeon |
| **System** | Ubuntu 22.04.1 LTS, Kernel 5.15.0-43-generic |
| **Storage (root)** | 1.7 TB LVM — `/dev/mapper/vgubuntu-root` |
| **Storage (data)** | LVM, mounted at `/data` |
| **Proxy** | `http://10.10.60.140:7890` (via `~/.bashrc`) |

### Network Interfaces

| Interface | Hardware | Speed | IP | Purpose |
|-----------|----------|-------|----|---------|
| ens20f0 | Intel I350 (igb) | 1 Gb/s | 10.10.70.96 | Management, SSH |
| ens35f0np0 | ConnectX-6 Dx (mlx5) | 100 Gb/s | 10.10.71.96 | vLLM NCCL/Gloo/TP |
| ens35f1np1 | ConnectX-6 Dx (mlx5) | 100 Gb/s | — | Unused (no cable) |

ens35f0np0 is configured via NetworkManager (persistent across reboots):

## Role: DeepSeek-V4-Pro Master Node (PP=2 Multi-Node)

Both strategies have been tested. **PP=2 (Pipeline Parallelism) is the recommended strategy** — it outperforms DP=2 across all metrics:

| Metric | DP=2 | PP=2 | PP Advantage |
|--------|------|------|-------------|
| Short prompt TTFT (S1) | 2.6s | **2.2s** | 15% faster |
| Long prompt TTFT (S2) | 260.5s | **186.7s** | 28% faster |
| Prefix cache TTFT (S3) | 142.8s | **43.2s** | 3.3× faster |
| Prefix throughput | 4.14 tok/s | **7.73 tok/s** | 87% more |

### Startup Scripts

**PP=2 (recommended):** `/data/venvs/vllm-ds4/start_dsv4_pro_2node.sh`
```bash
# Master (70.96):
bash /data/venvs/vllm-ds4/start_dsv4_pro_2node.sh master
# Worker (70.98):
bash /data/venvs/vllm-ds4/start_dsv4_pro_2node.sh worker
```

**DP=2 (alternative):** `/data/venvs/vllm-ds4/start_dsv4_pro_tp8_dp2_ep.sh`

### Architecture Comparison

**PP=2 (Pipeline Parallelism):**
- Model layers split across nodes — each node holds ~half the layers
- All GPUs participate in every request (both nodes work on prefill+decode in pipeline)
- Cross-node communication via NCCL (TP group spans both nodes)
- No DP coordinator handshake overhead
- Best for: prefix cache workloads, long prompts, balanced throughput

**DP=2 (Data Parallelism):**
- Each node holds full model weights sharded by TP+EP
- Different requests processed in parallel on each node
- DP coordinator does ZMQ handshake for every batch, adding latency
- More KV cache pressure (each node needs full model + KV cache)
- **DP handshake can fail** — 5-minute timeout with "Did not receive response from front-end process"

### PP=2 Startup Configuration

The proven PP=2 startup script (`start_dsv4_pro_2node.sh`) handles all NCCL/Gloo env vars:

```bash
export NCCL_SOCKET_IFNAME=ens35f0np0
export GLOO_SOCKET_IFNAME=ens35f0np0
export TP_SOCKET_IFNAME=ens35f0np0
export VLLM_HOST_IP="10.10.71.96"  # master; worker uses 10.10.71.98
export MASTER_ADDR="10.10.71.96"
export NCCL_IB_DISABLE=0
export NCCL_IB_HCA=mlx5_0
export NCCL_IB_GID_INDEX=3
export NCCL_IB_TIMEOUT=23
export NCCL_IB_QPS_PER_CONNECTION=4
export NCCL_IB_TC=136
export NCCL_CROSS_NIC=0
export NCCL_ALGO=Ring
export NCCL_MIN_NCHANNELS=8
export NCCL_NET=IB
```

Key: **`VLLM_HOST_IP` must be set** to the node's own 10.10.71.x IP (high-speed network). Without this, the multiproc executor uses loopback (127.0.0.1) for distributed_init_method, preventing cross-node NCCL communication.

### Startup Order (Important)

1. Start the **worker** first
2. Wait ~30-45 seconds for model init
3. Start the **master**

Starting the master first causes a ZMQ `Cannot assign requested address` error because the worker-side `VLLM_HOST_IP` binding isn't ready yet.

### NCCL Version Requirement

Blackwell (compute capability 12.0) requires **NCCL ≥ 2.30**. The torch-bundled NCCL 2.28.9 fails with:
- `NCCL error: invalid usage` during `ncclCommInitRank`
- `NCCL error: unhandled system error` during `ncclAllReduce`

**Fix:** Copy the system NCCL 2.30.4 into the venv:
```bash
cp /usr/lib/x86_64-linux-gnu/libnccl.so.2.30.4 \
  /data/venvs/vllm-ds4/lib/python3.12/site-packages/nvidia/nccl/lib/libnccl.so.2
```
(Note: this may cause pynccl_wrapper API incompatibility. The working config was on the original torch-bundled NCCL with proper GPU reset.)

### PP=2 Startup Order

1. Start **worker** (70.98) first — it waits for master's TCPStore
2. Wait ~45 seconds
3. Start **master** (70.96)

### Diagnostic: Checking if the cluster is alive

The worker node (70.98) will NOT respond to `curl localhost:8000` — this is by design:

1. **Check master's health:**
   ```bash
   curl -s http://localhost:8000/health
   ```

2. **Verify with real inference (master node) — short prompt first:**
   ```bash
   # Start with few tokens to check responsiveness
   curl -s -X POST http://localhost:8000/v1/chat/completions \
     -H "Content-Type: application/json" \
     -d '{"model":"deepseek_v4_pro","messages":[{"role":"user","content":"hi"}],"max_tokens":10}'
   ```
   
   If the first request times out (common during warmup / first inference), try again with a short prompt — the server may be working fine but the first request can be slow due to Triton JIT compilation.

3. **Full response test (100 tokens):**
   ```bash
   curl -s -X POST http://localhost:8000/v1/chat/completions \
     -H "Content-Type: application/json" \
     -d '{"model":"deepseek_v4_pro","messages":[{"role":"user","content":"hi"}],"max_tokens":100}' | python3 -m json.tool
   ```

4. **Check worker's process health (from the worker):**
   ```bash
   ps aux | grep -E 'VLLM::EngineCore|VLLM::Worker'
   ```

5. **Check master's logs for successful inference:**
   ```bash
   tail -f /tmp/vllm*.log | grep "200 OK"
   ```

6. **Check GPU utilization on both nodes:**
   ```bash
   nvidia-smi --query-gpu=index,utilization.gpu,memory.used --format=csv,noheader
   ```

### Current Configuration (as of 2026-05-27)

The recommended production configuration for DeepSeek V4 Pro with PP=2:

```bash
bash /data/venvs/vllm-ds4/start_dsv4_pro_2node.sh master
```

This script uses:
- TP=8 + PP=2 + EP=8
- max-num-seqs=512, max-num-batched-tokens=8192  
- max-model-len=1,048,576, gpu-memory-utilization=0.92
- compilation mode=3, cudagraph=FULL_AND_PIECEWISE
- RoCE v2 (ConnectX-6, 100GbE) via ens35f0np0

> **Note:** `--no-enable-flashinfer-autotune` is irrelevant for DeepSeek V4 which uses MLA (Multi-Head Latent Attention) with a custom Triton backend — FlashInfer autotune has no effect on this model.

### Log Redirection (IMPORTANT)

The current startup script redirects vLLM output directly to a log file — **not** through `tee`:

```bash
vllm serve ... > "$LOG_FILE" 2>&1
```

This avoids a critical failure mode: if the `tee` process dies (OOM, disk pressure, log rotation), the pipe breaks and vLLM receives SIGPIPE, killing the entire server. Direct file redirection (`>`) has no intermediate process, so nothing can kill vLLM.

The log file pattern is `/tmp/vllm_tp8_dp2_$$.log` (where `$$` is the bash PID at launch time).

### API

**Endpoint:** `http://10.10.70.96:8000`
**Model name:** `deepseek_v4_pro`
**API key:** `sk-warpdriveai`

## vLLM Environment

- Source: `/data/vllm-ds4-sm120/`
- Venv: `/data/venvs/vllm-ds4/` (Python 3.12, PyTorch 2.11.0+cu130)
- CUDA dev packages installed

## Quick Health Check

```bash
ssh jianliu@10.10.70.96 "source ~/.bashrc && \
  echo '=== GPU ==='; nvidia-smi --query-gpu=name,driver_version --format=csv,noheader | head -1; \
  echo '=== CUDA Driver ==='; nvidia-smi -q | grep 'CUDA Version'; \
  echo '=== Memory ==='; nvidia-smi --query-gpu=memory.used,memory.total --format=csv,noheader; \
  echo '=== Disk ==='; df -h / /data | tail -2"
```

## Batch Operations (cluster)

Part of 93/95/96 cluster — use bulk commands:

```bash
for h in 93 95 96; do
  echo "=== 10.10.70.$h ==="
  ssh jianliu@10.10.70.$h "source ~/.bashrc && command"
done
```

### Pitfalls

- **Blackwell (sm120) + NCCL 2.28.9 incompatibility** — The torch-bundled NCCL 2.28.9 does not support Blackwell compute capability 12.0. Symptom: `NCCL error: invalid usage` during `ncclCommInitRank` or `NCCL error: unhandled system error` during `ncclAllReduce`. System NCCL 2.30.4 supports sm120 but swapping the .so into the venv may cause pynccl_wrapper API version mismatch. **Fix:** GPU reset (`sudo nvidia-smi -r` or reboot) sometimes resolves transient NCCL state corruption. If persistent, the NCCL library in the venv needs to be upgraded to ≥ 2.30.
- **Proxy required** — Always `source ~/.bashrc` before any command. Non-interactive SSH never loads `.bashrc`.
- **Gloo 127.0.1.1 bug** — `/etc/hosts` maps `127.0.1.1 → oem96`, causing Gloo TCPStore to fail when `mode=VLLM_COMPILE`. Workaround: set `MASTER_ADDR=10.10.71.96` and `VLLM_HOST_IP=10.10.71.96`.
- **5-minute EngineCore handshake timeout** — The ds4-sm120 vLLM branch has a hard-coded 300-second timeout in `startup_handshake`. With DeepSeek-V4-Pro (806 GB, FP8, 1M context), KVCache profiling + compile mode=3 can exceed this, even on a single-node DP=1 setup. Symptoms: `RuntimeError: Did not receive response from front-end process within 5 minutes` in the log after ~5 minutes of apparent inactivity. Workarounds: reduce `max-model-len`, lower `gpu-memory-utilization`, add `VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS=1`, or avoid DP > 1.
- **Port reuse** — Master port can get stuck with TCP store from previous run. Always use a new port on restart.
- **`!` in password** — When using the password in bash, wrap in single quotes: `'!QAZ2wsx'` to prevent history expansion.
- **ConnectX-6 vs Intel NIC** — `ens20f0` is the 1GbE Intel NIC, `ens35f0np0` is the 100G ConnectX-6. NCCL must use `ens35f0np0` for multi-node communication.
- **FlashInfer irrelevant** — DeepSeek V4 uses MLA attention (Triton backend). FlashInfer autotune flags have no effect.

## Network Hardware Discovery

Quick check for NIC inventory on a node:

```bash
lspci | grep -i mellanox          # physical card
ip -br link show                   # all interfaces
ethtool ens35f0np0 | grep Speed    # link speed
rdma link show                     # RDMA state
ls /sys/class/infiniband/          # IB devices
lsmod | grep mlx5                  # driver loaded
```

## References

Detailed notes in `references/`:
- `references/70-96-detailed-setup.md` — Full setup details
